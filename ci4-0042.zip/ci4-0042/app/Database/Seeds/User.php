<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class User extends Seeder
{
    public function run()
    {
        //
        $data = [
            'username' => 'admin',
            'password' => password_hash('admin', PASSWORD_DEFAULT),
            'nama_lengkap' => 'Muhammad Ilham Sahada',
            'email' => 'ilhamsahada64@gmailcom'
        ];
        $this->db->table('user')->insert($data);
    }
}